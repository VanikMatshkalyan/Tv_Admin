create
    definer = root@`%` procedure getTopMovieIdsV3(IN companyId bigint, IN startDate timestamp, IN assetType int,
                                                  IN locale text, IN sourceType int, IN provider bigint,
                                                  IN regionId bigint)
BEGIN
SELECT SEL.id, COALESCE(SEL.app_market_id , SEL.default_market_id) app_market_id, SEL.movieId, SEL.duration, SEL.price, SEL.currency,
       COALESCE(SEL.title, SEL.titleEn) title, SEL.year,  SEL.audio, SEL.description, SEL.imdb_rating, SEL.mpaa_rating, SEL.server, SEL.source_type, SEL.service_point_type,
       SEL.trailer_path, SEL.file_path, SEL.ios_trailer_path, SEL.ios_file_path, SEL.ios_server, SEL.thumbnail, SEL.poster, SEL.banner,
       SEL.mobile_bandwidth, SEL.android_box_group1_bandwidth, SEL.android_box_group2_bandwidth, SEL.android_apk_bandwidth,
       max(case when SEL.tag_type_id = 1 then SEL.tag_id end) tag_id,
       max(case when SEL.tag_type_id = 2 then SEL.tag end) directors,
       max(case when SEL.tag_type_id = 3 then SEL.tag end) actors,
       max(case when SEL.tag_type_id = 4 then SEL.tag end) genre, movie_type,  SEL.iso_code , SEL.asset_id_count
FROM (SELECT rv.id,  rv.app_market_id, (SELECT app_market_id FROM vod_price) as default_market_id, vm.id as movieId, vm.duration, vm.service_point_type, rv.price, rv.currency, vmm.title title, vmmEn.title titleEn, vm.year,  vm.audio, vmm.description,
             vm.imdb_rating, vm.mpaa_rating, vd.server, vd.trailer_path, vd.file_path, vd.ios_server, vd.ios_trailer_path, vd.ios_file_path, vd.source_type, rv.poster,  vm.thumbnail,  vm.banner, tg.tag_type_id,
             vd.mobile_bandwidth, vd.android_box_group1_bandwidth, vd.android_box_group2_bandwidth, vd.android_apk_bandwidth,
             GROUP_CONCAT(tagmsg.NAME SEPARATOR ' , ') AS tag, cat.id as tag_id, vm.movie_type  ,
             (SELECT group_concat(rgn.iso_code separator ',') iso_code  FROM region_vod rv2 INNER join region rgn on rgn.id = rv2.region_id where rv2.vod_id = vd.id) iso_code , T.asset_id_count
      FROM vod_movie vm
               LEFT JOIN vod_movie_msg vmm ON vm.id = vmm.vod_movie_id AND vmm.locale = locale
               LEFT JOIN vod_movie_msg vmmEn ON vm.id = vmmEn.vod_movie_id AND vmmEn.locale = 'en_US'
               INNER JOIN vod vd ON vm.id = vd.movie_id
               INNER JOIN provider_vod pvd ON vd.id = pvd.vod_id AND pvd.provider_id = provider
               INNER JOIN region_vod rv ON vd.id = rv.vod_id AND rv.region_id = regionId and rv.status = 1
               INNER JOIN vod_movie_tag mtg ON mtg.movie_id = vm.id
               INNER JOIN tag tg ON tg.id = mtg.tag_id AND tg.status > 0
               INNER JOIN tag_msg tagmsg ON tagmsg.tag_id = mtg.tag_id AND tagmsg.locale = locale
               LEFT JOIN tag cat ON cat.id = mtg.tag_id AND cat.tag_type_id = 1
               INNER JOIN tag_type tt on tt.id = vm.movie_type
               INNER JOIN (SELECT asset_id, asset_title, COUNT(*) AS asset_id_count
                           FROM subscription_management.purchase
                           WHERE asset_type = assetType
                             AND asset_id IN (SELECT id FROM vod_movie WHERE status = 1)
                             AND purchased_at  > startDate
                           GROUP BY asset_id, asset_title
                           ORDER BY asset_id_count DESC Limit 0, 10
      ) AS T on T.asset_id = vm.id
      WHERE vm.status > 0 AND vd.source_type = sourceType AND rv.region_id = regionId AND vm.company_id = companyId
      GROUP BY rv.id, movieId, vm.duration, vm.service_point_type, rv.price, rv.currency, vmm.title, vm.year,  vm.audio, vmm.description, vm.imdb_rating, vd.server, vd.trailer_path,
               vd.file_path, vd.ios_server, vd.ios_trailer_path, vd.ios_file_path,
               vd.mobile_bandwidth, vd.android_box_group1_bandwidth, vd.android_box_group2_bandwidth, vd.android_apk_bandwidth, rv.poster, vm.mpaa_rating, tg.tag_type_id ,cat.id, iso_code, asset_id_count ) SEL
GROUP BY SEL.id,  SEL.movieId, SEL.title, SEL.price, SEL.currency, SEL.duration, SEL.year,  SEL.audio, SEL.description, SEL.imdb_rating, SEL.mpaa_rating,
         SEL.server, SEL.trailer_path, SEL.file_path, SEL.ios_trailer_path, SEL.ios_file_path, SEL.ios_server, SEL.thumbnail, SEL.poster, SEL.banner, SEL.source_type, SEL.service_point_type,
         SEL.mobile_bandwidth, SEL.android_box_group1_bandwidth, SEL.android_box_group2_bandwidth, SEL.android_apk_bandwidth, SEL.iso_code, SEL.asset_id_count
order by SEL.asset_id_count desc;
END;

